package com.ibm.academia.restapi.universidad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiUniversidadMApplication 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(ApiUniversidadMApplication.class, args);
	}
}