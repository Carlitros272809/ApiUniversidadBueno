package com.ibm.academia.restapi.universidad.enumeradores;

public enum TipoEmpleado 
{
	ADMINISTRATIVO,
	MANTENIMIENTO
}