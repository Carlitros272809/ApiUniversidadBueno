package com.ibm.academia.restapi.universidad.controladores;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/restapi")
public class MiPrimerController 
{
	private final static Logger logger = LoggerFactory.getLogger(MiPrimerController.class);
	
	@GetMapping("/hola-mundo")
	public ResponseEntity<?> miPrimerEndpoint()
	{
		Map<String, String> respuesta = new HashMap<String, String>();
		respuesta.put("mensaje", "Hola mundo desde REST");
		
		logger.trace("trace log");
		logger.debug("debug log");
		logger.info("info log");
		logger.warn("warning log");
		logger.error("error log");
		
		return new ResponseEntity<Map<String, String>>(respuesta, HttpStatus.ACCEPTED);
	}
}