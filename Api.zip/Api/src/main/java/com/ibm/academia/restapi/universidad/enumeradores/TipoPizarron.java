package com.ibm.academia.restapi.universidad.enumeradores;

public enum TipoPizarron 
{
	PIZARRON_TIZA,
	PIZARRON_BLANCO
}
